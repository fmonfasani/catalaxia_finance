"""
Busca evidencia de origen del fixture TIKR.
NO fabrica provenance.
Busca:
- archivos fuente Excel/CSV
- referencias al fixture
- hashes
- celdas/hojas documentadas
"""
from pathlib import Path
import hashlib, json, re, pandas as pd

fixture_candidates = [
    Path("fixtures/tikr_fx_12.csv"),
    Path("research/fx_tikr_reverse/fixtures/tikr_fx_12.csv"),
]
fixture = next((p for p in fixture_candidates if p.exists()), None)
if not fixture:
    raise SystemExit("FAIL: tikr_fx_12.csv no encontrado")

sha = hashlib.sha256(fixture.read_bytes()).hexdigest()
df = pd.read_csv(fixture)

required = {"period","target_date","tikr_fx"}
missing = required - set(df.columns)
if missing:
    raise SystemExit(f"FAIL: fixture missing columns: {missing}")

search_roots = [
    Path("."),
    Path("research"),
    Path("data"),
    Path("tikr"),
    Path("fixtures"),
]
source_hits = []

patterns = [
    r"TIKR", r"tikr_fx", r"currency conversion", r"FX",
    r"349\.97", r"808\.46", r"857\.22", r"911\.50", r"968\.50",
    r"1030\.50", r"1073\.10", r"1204\.50", r"1379\.70",
    r"1451\.00", r"1382\.00", r"1483\.70"
]

for root in search_roots:
    if not root.exists():
        continue
    for p in root.rglob("*"):
        if not p.is_file() or p == fixture:
            continue
        if any(part in {".git","__pycache__","node_modules"} for part in p.parts):
            continue
        if p.suffix.lower() not in {".md",".txt",".csv",".json",".xlsx",".xls",".yaml",".yml"}:
            continue
        try:
            if p.suffix.lower() in {".xlsx",".xls"}:
                sheets = pd.read_excel(p, sheet_name=None)
                text = "\n".join(
                    f"{sheet}\n{frame.astype(str).to_csv(index=False)}"
                    for sheet, frame in sheets.items()
                )
            else:
                text = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        hits = [pat for pat in patterns if re.search(pat, text, re.I)]
        if hits:
            source_hits.append({"file":str(p), "hits":hits[:20]})

result = {
    "fixture": str(fixture),
    "fixture_sha256": sha,
    "rows": len(df),
    "source_candidates_found": source_hits,
    "provenance_status": "SOURCE_FOUND_CANDIDATE" if source_hits else "NO_PRIMARY_SOURCE_FOUND",
    "decision": "REQUIRES_MANUAL_SOURCE_BINDING"
}

Path("outputs/tikr_provenance_audit.json").write_text(
    json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8"
)
print(json.dumps(result, indent=2, ensure_ascii=False))
